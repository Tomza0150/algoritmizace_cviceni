﻿/*
//priklad 1
int a, soucet=0, n;
double prumer;


do
{
    Console.WriteLine("Zadejte celé číslo:");
    n = int.Parse(Console.ReadLine());
 
}

while (n <= 0); //vše musí být kladné
int[] pole = new int[n];

for (int i = 0; i < n; i++)
{
    Console.WriteLine("Zadejte číslo: ");
    pole[i] = int.Parse(Console.ReadLine()) ;
    soucet += pole[i];
}
 

prumer = (double)soucet / n;
Console.WriteLine("Aritmetický průměr {0} čísel je {1}.",n,prumer);

// todo nalezení prvku, který je od průměru nejvzdálenější
//int nejdal = pole[0];
int indexMaxPrvek = 0;
double maxodchylka = Math.Abs(prumer - pole[indexMaxPrvek]);
for (int i = 0; i < n; i++)
{
    double arozdil = Math.Abs(pole[i]-prumer);
    if (arozdil <maxodchylka)
    {
        maxodchylka = arozdil;
        pole[indexMaxPrvek] = i;
    }
}
Console.WriteLine("Prvek nejdál od průměru má hodnotu {0} a je na {1}. pozici.", pole[indexMaxPrvek], indexMaxPrvek+1);
Console.ReadKey();
*/
//priklad 2
/*
int n;
do
{
    Console.WriteLine("Zadejte celé číslo:");
    n = int.Parse(Console.ReadLine());

}

while (n <= 2);
double[] pole = new double[n];

for  (int i = 0; i < n; i++)
{
    Console.WriteLine("Zadejte čísla: ");
    pole[i] = double.Parse(Console.ReadLine());
}
bool r = true;
bool k = true;
for  (int i = 0;i < n-1; i++)
{
    if (pole[i + 1] <= pole[i]&&r)
    {
        r = false;
    }
    else if (pole[i + 1] >= pole[i] && k)
    {
        k=false;
    }
    if (!k && !r)
    {
        break;
    }
}

if (k)
{
    Console.WriteLine("Posloupnost je klesající.");
}
else if (r)
{
    Console.WriteLine("Posloupnost je rostoucí.");
}
else
{
    Console.WriteLine("Posloupnost není ani rostucí ani klesající.");
}
*/






//priklad 3 - najít chybu

// Program pro načtení pole celých čísel v jediném řetězci a převedení na pole čísel v programu

Console.Write("Zadej celá čísla oddělená alespoň jednou mezerou:");
string vstup = Console.ReadLine() + " ";
int n = 0;

// zjištění počtu čísel => průchod od prvního do předposledního
for (int i = 0; i < vstup.Length; i++)
{
    // pokud i-tý znak není mezera a znak za ním je, tak víme, že se jedná o poslední znak jednoho prvku
    if (vstup[i] != ' ' && vstup[i + 1] == ' ')
    {
        n++;
    }
}

// již známe počet prvků n, a proto můžeme vytvořit NOVÉ pole pro n prvků
int[] cisla = new int[n];
int zacatek = 0; // počáteční index ze vstupu, kde začíná prvek, který budeme načítat do pole
int delka = 1; // počet znaků, který zabírá prvek, který budeme načítat do pole
int iVstup; // aktuální index ve vstupu
int iCisla; // aktuální index v poli, do kterého načítáme prvky

// v tomto cyklu budeme procházet vstup, dokud nenačteme všechny prvky pole
for (iVstup = 0, iCisla = 0; iCisla <= n; iVstup++)
{
    if (vstup[iVstup] != ' ' && vstup[iVstup + 1] == ' ') // tzn došli jsme na konec prvku
    {
        // získáme podřetězec, který obsahuje pouze daný prvek
        string podretezec = vstup.Substring(zacatek, delka);
        // daný podřetězec převedeme na číslo a načteme do pole
        cisla[iCisla] = int.Parse(podretezec);

        // po načtení prvku inkrementujeme index
        iCisla++;
        // začátek dalšího prvku posuneme na následující znak vstupu
        zacatek = iCisla + 1;
        // délku nastavíme na nejmenší možnou délku prvku
        delka = 1;
    }
    else if (vstup[iVstup] != ' ') // pokud jsme nedošli na konec prvku a nejedná se o mezeru
    {
        delka++; // jsme "uprostřed" prvku a potřebujeme zvětšit délku načítaného řetězce
    }
    else // jinak se jedná o mezeru
    {
        zacatek++; // posuneme začátek dalšího prvku o jedna
    }
}

// vypíšeme každý prvek na jeden řádek
Console.WriteLine("Výpis prvůk:");
for (int i = 0; i < n; i++)
{
    Console.WriteLine(cisla[i]);
}

Console.Write("Program ukončíte stiskem libovolné klávesy.");
Console.ReadKey();