﻿using System.Security.Authentication.ExtendedProtection;
/* prikald 1
int n, soucet = 0, vnp=0;
double prumer;
do
{
    Console.WriteLine("Zadejte kladné číslo:");
    n = int.Parse(Console.ReadLine());
    
}
while (n <= 0);
int[] pole = new int[n];
for (int i = 0; i < n; i++)
{
    
    Console.WriteLine("Zadejte {0}. prvek", i + 1);
    pole[i] = int.Parse(Console.ReadLine());
    soucet += pole[i];
}


prumer =(double)soucet/n;

for (int i = 0; i < n; i++)
{
    Console.Write(pole[i] + " ");
    if (pole[i] > prumer)
    {
        vnp++;
    }
        

}
Console.WriteLine("");
Console.WriteLine("Aritmetický průměr: {0:F2}", prumer);
Console.WriteLine("Počet větších než aritmetický průměr: {0}", vnp);

//priklad 2
int n;
do
{
    Console.WriteLine("Zadejte kladné číslo:");
    n = int.Parse(Console.ReadLine());

}
while (n <= 0);
int[] a=new int[n];
for (int i=0;i<n;i++)
{
    Console.WriteLine("Zadejte {0}. prvek: ", i +1);
    a[i]=int.Parse(Console.ReadLine());
}

bool obsahujesude = false;
int sudemax = a[0];

for(int i=0;i<n; i++)
{
    if (a[i] % 2 == 0 && (a[i]>sudemax||!obsahujesude))
    {
        obsahujesude = true;
        sudemax=a[i];
    }
}

if (obsahujesude)
{
    Console.Write("Největší sudé číslo je {0} a jeho indexy jsou:", sudemax);
    for (int i = 0; i < n; ++i)
    {
        if (a[i] == sudemax)
        {
            Console.Write(i + ", ");
        }
    }
}
else
{
    Console.WriteLine("Neobsahuje žádné sudé číslo.");
}*/

int n;
double prumer, rozdil, soucet=0;
bool vypsano=false;
string zh="Zadané hodnoty", cc="Celá část hodnot", rp="rozdíl průměru všech hodnot a dané hodnoty prvku";
do
{
    Console.WriteLine("Zadejte kladné číslo:");
    n = int.Parse(Console.ReadLine());
}
while (n <= 0);
double[] a = new double[n];
for (int i = 0; i < n; i++)
{
    Console.WriteLine("Zadejte {0}. prvek: ", i + 1);
    a[i] = double.Parse(Console.ReadLine());
    soucet += a[i];
}

for (int i = 0;i < n; i++)
{
 prumer = soucet / n;
rozdil=Math.Abs(prumer - (double)a[i]);

    if (!vypsano)
    {
        Console.WriteLine("{0,-20} {1,-20} {2,-20}", zh, cc, rp);
        vypsano = true;
    }
     Console.WriteLine("{0,-30:F2} {1,-35} {2,-60:F2}", a[i], (int)a[i], rozdil);
    


}
