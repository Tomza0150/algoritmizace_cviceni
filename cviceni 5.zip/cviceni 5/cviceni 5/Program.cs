﻿/*
 pocet = 0;
Console.WriteLine("Zadávej reálná čísla a pro ukončení zadej 0.");

do
{
    
    x = double.Parse(Console.ReadLine());
    if (x == 0) break;
    soucet += x;
    pocet++;
}

while (x != 0);

if (pocet == 1)
{
    Console.WriteLine("Špatný vstup.");
}
else
{
    prumer=soucet/(pocet); 
    prumer = Math.Round(prumer, 2);
    Console.WriteLine("Průměr všech čísel je: " + prumer);
}
Console.ReadKey();
*/
/*
while (true)
{
    int a, b, nsn;

    do
    {
        Console.WriteLine("Zadejte kladné cele číslo a: ");
        a = int.Parse(Console.ReadLine());
        Console.WriteLine("Zadejte kladné celé číslo b: ");
        b = int.Parse(Console.ReadLine());

    }
    while (a <= 0 || b <= 0);
    int x = 0;
    do
    {
        x++;
    }
    while ((x * a) % b != 0);
    nsn = x * a;

    Console.WriteLine("Nejmenší společný násobek je: {0}", nsn);
    Console.WriteLine("pokud chcete pokračovat, zadejte ano.");
    if(Console.ReadLine()!="ano")
    {
        break;
    }
}

*/

/*
int r=0, h=0, ch=0, k=0, pocetCelkem=0;
double cenar = 2.9, cenah = 3.4, cenach = 29.9, cenak=10;
Console.WriteLine("Zadejte rohlík, houska, chleba tolikrát, kolikrát je chcete koupit.");
do
{
    string vstup = Console.ReadLine();
    if (vstup == "rohlík")
    {
        r++;
    }
    else if (vstup == "houska")
    {
        h++;
    }
    else if (vstup == "chleba")
    {
        ch++;
    }
    else if (vstup=="koláček")
    {
        k++;
    }
    else if (vstup == "0")
    {
        break;
    }
    else
    {
        Console.WriteLine("neznámý vstup ignorován.");
    }
    pocetCelkem++;
}
while (pocetCelkem < 10);

if(r>0)
{
    Console.WriteLine("{0}xrohlík = {1:F2}", r, r * cenar);
}
if (h > 0)
{
    Console.WriteLine("{0}xhouska = {1:F2}", h, h * cenah);
}
if (ch > 0)
{
    Console.WriteLine("{0}xchleba = {1:F2}", ch, ch * cenach);
}
if (k > 0)
{
    Console.WriteLine("{0}xkoláček = {1}", k, k * cenak);
}
*/

double p, m, urok, cil, mnozstvi;
int doba=0;
Console.WriteLine("Zadejte počáteční vklad: ");
p=double.Parse(Console.ReadLine());
Console.WriteLine("Zadejte měsíční vklad: ");
m=double.Parse(Console.ReadLine());
Console.WriteLine("Zadejte úrok: ");
urok=double.Parse(Console.ReadLine());
Console.WriteLine("Zadejte cílovou částku:");
cil=double.Parse(Console.ReadLine());

do
{
    if (p+m<0)
    { break; }
    if (m+urok<0)
        { break; }
    if (cil<p)
        { break; }
    p += m;
    mnozstvi = p * urok;
    doba += 1;
}

while (mnozstvi == cil);

Console.WriteLine("Cílovou částku {0} naspoříte za {1} měsíců.", cil, doba);