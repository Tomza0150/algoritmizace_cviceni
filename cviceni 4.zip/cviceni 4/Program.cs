﻿/*int i, n;
Console.WriteLine("Zadejte počet čísel: ");
n=int.Parse(Console.ReadLine());
i = 1;
while (i<=1)
{
    Console.Write(i + " ");
    i++;
}
Console.WriteLine();
Console.ReadKey();
*/

/*int i, n;

i = 1;
Console.WriteLine("Zadejte kladné celé číslo n:");
n=int.Parse(Console.ReadLine());
int soucet = n;
if (n<=0)
{
    Console.WriteLine("Neplatná hodnota, program bude ukončen.");
    return;
}

else
{
    while (i<n)
    {
        Console.Write("{0}, ",i);
        soucet = soucet + i;
        i++;
    }
    Console.WriteLine(i);
    Console.WriteLine("Součet čísel ar. pos. je {0}: ", soucet);
}
Console.WriteLine("Program se ukončí stiskem libovolné klávesy.");
Console.ReadKey();
*/
/*int n;
Console.WriteLine("Zadejte celé číslo: ");
n = int.Parse(Console.ReadLine());
int soucet = 0;
int cislice = 0;
while (n > 0)
{
    cislice++;
    soucet += n % 10;
    n = n / 10;
}

Console.WriteLine("Počet číslic je {0} a součet je {1}.", cislice, soucet);
Console.WriteLine("Program se ukončí stiskem libovolné klávesy.");
Console.ReadKey();
*/
Console.WriteLine("Zadejte celé číslo: ");
int n = int.Parse(Console.ReadLine());

if (n<=0)
{ Console.WriteLine("Neplatná hodnota");
}
else
{
    int sum = 0;
    int min = int.MinValue;
    int max = int.MaxValue;
    while (n>0)
    {
        Console.WriteLine("Zadejte číslo: ");
        int num = int.Parse(Console.ReadLine());
        sum += num;
        if (num > max)
        {
            max = num;

        }
        if (num<min)
        {
            min = num;
        }
        n--;
    }
    Console.Write("Součet čísel je {0}, největší číslo je {1} a nejmenší je {2}.", sum, max, min);
}
