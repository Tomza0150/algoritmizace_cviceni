﻿/*int n, i;

do
{
    Console.WriteLine("Zadejte celé číslo: ");
    n = int.Parse(Console.ReadLine());
}
while (n<=0);

for (i=1;i<=n;i++)
{
    if (i % 3 == 0)
    {
        Console.Write(i + ", ");
    }
    }

Console.WriteLine("Varianta b:");
for (int i=1;i<=n;i++)
{
    if (i%3!=0)
    { continue;
    }
    Console.Write(i + ", ");
}

if (n<3)
{
    Console.WriteLine("Pro zadané n neexistuje celé číslo od 1 do n, které je dělitelné číslem 3.");
}


*/
/*
int k;
for (k=0;k<=0||k>180;k=int.Parse(Console.ReadLine()))
        {
    Console.WriteLine("Zadejte kladné číslo, maximálně 180:");
}

Console.WriteLine("˝{0,3} {1,6}", "x", "sin(x)");


for (int s = 0; s <= 180; s += k)
{
    double r = s * Math.PI / 180;
    double sinus = Math.Sin (r);
    Console.WriteLine("{0,3} {1,6:F3}", s, sinus);
}

Console.ReadKey();
*/
/*
//varianta a
Console.WriteLine("Zadejte číslo");
int n = int.Parse(Console.ReadLine());
bool jeprvocislo1 = true;
bool jeprvocislo2 = true;

if (n<=1)
{
    jeprvocislo1 = false;
    jeprvocislo2=false;
}
double odmocnina = Math.Sqrt(n);
int delitel = 2;
while (delitel<=odmocnina&&jeprvocislo1)
{
    if (n % delitel == 0)
    {
        jeprvocislo1 = false;
    }
    delitel++;
}
//varianta b
for (int i =2; i<=odmocnina; i++)
{
    if (n%i==0)
    {
        jeprvocislo2 = false;
        break;
    }
}

if (jeprvocislo1 && jeprvocislo2)
{
    Console.WriteLine("číslo je prvočíslo, výsledek je shodný.");
}
else if (!jeprvocislo1&& !jeprvocislo2)
{
    Console.WriteLine("Číslo je prvočíslo podle 1 algoritmu a podle druhého ne.");
}
else
    Console.WriteLine("ČVýsledky se neshodují, někde nastala chyba.");



/*
//varianta moje
int n, p, d;
Console.WriteLine("Zadejte celé číslo n:");
n=int.Parse(Console.ReadLine());

for (d=2; d <= Math.Sqrt(n); d++)
{
    if (n%p!=0)
    {
    
        Console.WriteLine("Číslo {0} je prvočíslo.", n);
    }
}
*/


//načíst 2 celá čísla
//vypsat A na B pro B >=0
//výpočet pomocí for 
//formát výstupu <a> ^ <b>=<a^b>

int a, b, i;
Console.WriteLine("Zadejte číslo a:");
a=int.Parse(Console.ReadLine());
Console.WriteLine("Zadejte číslo b:");
b=int.Parse(Console.ReadLine());
double v, a1=a;
for (i = b; i >= 0; i--)
{
    double i1 = i;
    v =Math.Pow(a1,i1);
    Console.Write("{0,10} ^ {1,10} = {2,10}.", a1, i1, v);
}
Console.ReadKey();




